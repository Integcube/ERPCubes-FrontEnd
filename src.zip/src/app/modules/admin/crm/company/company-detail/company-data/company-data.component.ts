import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-company-data',
  templateUrl: './company-data.component.html',
  styleUrls: ['./company-data.component.scss']
})
export class CompanyDataComponent implements OnInit {
  panelOpenState:boolean

  constructor() { }

  ngOnInit(): void {
  }

}
